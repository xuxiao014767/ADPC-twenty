%Clustering by fast search and find of density peaks
clear 
clc 


data = xlsread('twenty.xlsx');
labels=xlsread('label.xlsx');


ND = size(data,1);
N=ND*(ND-1)/2;

distM = pdist2(data, data); 

percent = 2;
position=round(N*percent/100);
sda=sort((distM(triu(true(size(distM)),1)))');
dc=sda(position);

for i=1:ND
  rho(i)=1;
end
maxd=max(max(distM));

for i=1:ND-1
  for j=i+1:ND
     rho(i)=rho(i)+exp(-(distM(i,j)/(dc))^2);
     rho(j)=rho(j)+exp(-(distM(i,j)/(dc))^2);
  end
end

[rho_sorted,ordrho]=sort(rho,'descend');
delta(ordrho(1))=-1.;
nneigh(ordrho(1))=0;

for ii=2:ND
   delta(ordrho(ii))=maxd;
   for jj=1:ii-1
     if(distM(ordrho(ii),ordrho(jj))<delta(ordrho(ii)))
        delta(ordrho(ii))=distM(ordrho(ii),ordrho(jj));
        nneigh(ordrho(ii))=ordrho(jj);
     end
   end
end
delta(ordrho(1))=max(delta(:));

rho = rho./max(rho);
delta = delta./max(delta);


r=rho.*delta;
[r_sorted,ordr]=sort(r,'descend');

t1=cputime;

numC = zeros(1, round(sqrt(ND)));
for c = 1:round(sqrt(ND))
    cl = zeros(ND, 1) - 1;
    icl = ordr(1:c);
    for k = 1:c
        cl(icl(k)) = k;
    end
    for i = 1:ND
        if cl(ordrho(i)) == -1
            cl(ordrho(i)) = cl(nneigh(ordrho(i)));
        end
    end
    
    evaluation = evalclusters(data, cl, 'Silhouette');
    numC(c) = evaluation.CriterionValues;
end
numC(1) = max(numC);
NCLUST = find(numC==min(numC));


cl = zeros(ND, 1) - 1;
icl = ordr(1:NCLUST);
for k = 1:NCLUST
    cl(icl(k)) = k;
end
for i = 1:ND
    if cl(ordrho(i)) == -1
        cl(ordrho(i)) = cl(nneigh(ordrho(i)));
    end
end

for i=1:ND
  halo(i)=cl(i);
end

e1=cputime-t1;

cmap=colormap;
figure(1);
plot(data(:,1),data(:,2),'o','MarkerSize',2,'MarkerFaceColor','k','MarkerEdgeColor','k');
title ('Twenty','FontSize',20.0)
for i=1:ND
    A(i,1)=0.;
    A(i,2)=0.;
end
for i=1:NCLUST
    nn=0;
    ic=int8((i*64.)/(NCLUST*1.));
    for j=1:ND
        if (halo(j)==i)
            nn=nn+1;
            A(nn,1)=data(j,1);
            A(nn,2)=data(j,2);
        end
    end
    hold on
    plot(A(1:nn,1),A(1:nn,2),'o','MarkerSize',2,'MarkerFaceColor',cmap(ic,:),'MarkerEdgeColor',cmap(ic,:));
end


e1

true_labels=xlsread('label.xlsx');
cluster_labels=halo;
acc=accuracy(true_labels, cluster_labels')